document.addEventListener('DOMContentLoaded', function() {
    const links = document.querySelectorAll('.link');

    links.forEach(link => {
        link.addEventListener('click', function(event) {
            event.preventDefault(); // Prevent default link behavior

            const destination = this.getAttribute('href');

            // Apply fade-out animation to current page
            const currentPage = document.querySelector('.page');
            currentPage.style.animation = 'fadeOut 0.5s ease-in-out';

            setTimeout(() => {
                window.location.href = destination; // Redirect to new page after animation
            }, 500); // Wait for animation to complete (500ms)
        });
    });
});
